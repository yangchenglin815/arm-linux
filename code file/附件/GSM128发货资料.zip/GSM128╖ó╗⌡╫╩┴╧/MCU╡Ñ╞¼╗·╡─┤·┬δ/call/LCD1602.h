#ifndef  __LCD1602_H
#define  __LCD1602_H
#include "STC89C52.h"
void LCDInit(void);
void DisplayString(unsigned char X, unsigned char Y, unsigned char  *DData);						  



#endif