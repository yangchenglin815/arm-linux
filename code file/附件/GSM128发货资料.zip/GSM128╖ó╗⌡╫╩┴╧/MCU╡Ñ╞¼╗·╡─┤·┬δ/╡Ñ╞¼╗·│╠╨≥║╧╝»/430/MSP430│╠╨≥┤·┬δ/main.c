#include<msp430x14x.h>
#include"BoardConfig.h"
unsigned char AT[]="AT\r";                                //�����ź�//3Chars
unsigned char ATCMGF[]="AT+CMGF=1\r";                    //text��ʽ//10Chars
unsigned char ATCMGS[]="AT+CMGS=\"15922041115\"\r";

void GsmSend(void);
void UART0_Init (void);
void DelayNS (unsigned int dly);
void Delay(unsigned long t);

unsigned char Data[]="kiss";

//������
void main()
{
  BoardConfig(0xb8);
  WDTCTL = WDTPW +WDTHOLD;
  UART0_Init();
  DelayNS(50);//�ȴ�
  GsmSend();//����
  
}
//uart��ʼ��
void UART0_Init(void)
{
  ME1 |= UTXE0 +URXE0;
  UCTL0 = CHAR;
  UTCTL0 = SSEL0;
  UBR00 = 0X03;
  UBR10 = 0X00;
  UMCTL0 =0X4A;
  UCTL0 &= ~SWRST;
  IE1 |= URXIE0;
  P3SEL = 0X30;
  P3DIR = 0x10;
}
//ʱ���ӳ�
void DelayNS(unsigned int dly)
{
  unsigned int i;
  for(;dly>0;dly--)
    for(i=0;i<2000;i++);
}
//��Ϣ����
void GsmSend(void)
{
  unsigned char i;
  for(i=0;i<3;i++)
  {
    TXBUF0 = AT[i];           //AT[]="AT\r";
    while((IFG1 & UTXIFG0)==0);
  }
  DelayNS(50);
  for(i=0;i<10;i++)
  {
    TXBUF0 = ATCMGF[i];       //ATCMGF[]="AT+CMGF=1\r"
    while((IFG1 & UTXIFG0)==0);
  }
  DelayNS(50);
  for(i=0;i<22;i++)
  {
    TXBUF0 = ATCMGS[i];       //ATCMGS[]="AT+CMGS=\"15922041115\"\r"
    while((IFG1 & UTXIFG0)==0);
  }
  while(!(IFG1 & UTXIFG0));
  DelayNS(100);
  for(i=0;i<20;i++)
  {
    TXBUF0 = Data[i];
    while(!(IFG1 & UTXIFG0));
  }
  TXBUF0 = 0x1a;
  while(!(IFG1 & UTXIFG0));
}
